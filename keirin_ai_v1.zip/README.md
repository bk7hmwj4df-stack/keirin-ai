# 競輪AI v1
研究用プロトタイプです。

## 起動
pip install -r requirements.txt
streamlit run app.py

## 予想CSV
race_id,rider,score,S,H,B,style,line,recent_win_rate

## 過去CSV
上記に finish 列を追加。finish は1〜7。

v1は1着確率モデルとPlackett-Luce型の順位シミュレーションで210通りを作ります。
実戦用には、直近成績、開催場、競走間隔、決まり手、番手実績、天候/バンク、オッズ時系列などを追加して時系列検証してください。
